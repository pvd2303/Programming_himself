# код в module1
print("Привет!")

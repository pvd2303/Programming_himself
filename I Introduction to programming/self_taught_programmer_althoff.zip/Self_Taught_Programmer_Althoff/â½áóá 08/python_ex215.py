import keyword


keyword.iskeyword("для")
keyword.iskeyword("футбола")



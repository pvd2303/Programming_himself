# код в module2
import hello

import statistics

# среднее
nums = [1, 5, 33, 12, 46, 33, 2]
statistics.mean(nums)


# медиана
statistics.median(nums)


# мода
statistics.mode(nums)

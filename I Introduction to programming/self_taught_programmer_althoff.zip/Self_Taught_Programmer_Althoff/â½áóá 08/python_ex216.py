def print_hello():
    print("Привет")

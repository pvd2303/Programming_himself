mick = Person("Мик Джаггер")
stan = Dog("Стэнли",
           "Бульдог",
           mick)
print(stan.owner.name)

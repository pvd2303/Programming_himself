print("Привет, мир!")
print(200)
print(200.1)

if not win:
    print("\n"
          .join(stages[0: \
          wrong]))
    print("Вы проиграли! Было загадано слово: {}."
          .format(word))
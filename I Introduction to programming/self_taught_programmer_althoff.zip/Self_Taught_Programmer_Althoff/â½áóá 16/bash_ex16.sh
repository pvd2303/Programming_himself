$ ls --author

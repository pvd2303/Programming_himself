$ ls | less

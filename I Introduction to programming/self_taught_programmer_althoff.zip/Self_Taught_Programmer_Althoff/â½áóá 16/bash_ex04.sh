$ history

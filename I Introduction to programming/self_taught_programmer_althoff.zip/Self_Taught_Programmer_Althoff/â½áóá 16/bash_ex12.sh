$ cd ..

$ echo $x

$ cd ~
$ mkdir tstp
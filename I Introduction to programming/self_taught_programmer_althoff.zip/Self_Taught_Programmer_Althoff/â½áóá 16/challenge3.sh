#!/bin/bash
# добавляет строку в файл .profile.
export python_projects=~
cd $python_projects

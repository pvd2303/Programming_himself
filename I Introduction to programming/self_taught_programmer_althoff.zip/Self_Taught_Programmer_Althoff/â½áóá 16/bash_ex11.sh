$ cd tstp

$ grep красивое zen.txt

$ echo Я люблю $ | grep  \$

$ export GREP_OPTIONS='--color=always'
$export GREP_OPTIONS='--color=always'

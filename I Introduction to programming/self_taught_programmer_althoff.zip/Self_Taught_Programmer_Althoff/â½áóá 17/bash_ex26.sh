$ grep ^Если zen.txt

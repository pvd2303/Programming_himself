$ echo 123 хай 34 привет. | grep [[:digit:]]

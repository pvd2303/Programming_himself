$ echo Два даа. | grep  -i д[ав]а

$ echo ту тууу ура. | grep -o ту*

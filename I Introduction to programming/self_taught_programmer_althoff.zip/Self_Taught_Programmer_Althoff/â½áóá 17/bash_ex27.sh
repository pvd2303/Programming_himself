$  grep никогда.$ zen.txt

import re

match = re.findall(".ло", "Привидение прошуршало и и исчезло в углу.")
print(match)

$ grep -o Красивое zen.txt

 $ grep Красивое zen.txt

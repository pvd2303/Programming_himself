#!/usr/bin/env bash

echo Москва: 777, 999, 797. Тула: 071, 950, 112. | grep [[:digit:]]

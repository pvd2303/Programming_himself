#!/usr/bin/env bash
grep голландец zen.txt
$ grep -i красивое zen.txt

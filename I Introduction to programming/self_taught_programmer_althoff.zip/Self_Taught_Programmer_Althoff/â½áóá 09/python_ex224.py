with open("st.txt", "w") as f:
    f.write("привет от Python!")

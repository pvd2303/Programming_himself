st = open("st.txt", "w")
st.write("привет от Python!")
st.close()

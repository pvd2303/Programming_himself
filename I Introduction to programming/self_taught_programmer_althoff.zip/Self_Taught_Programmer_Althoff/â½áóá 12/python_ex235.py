a = 0


def increment():
    global a
    a += 1

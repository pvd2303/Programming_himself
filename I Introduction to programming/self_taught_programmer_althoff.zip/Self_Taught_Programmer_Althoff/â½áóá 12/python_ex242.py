class Orange:
    def __init__(self, w, c):
        self.weight = w
        self.color = c
        print("Создано!")

or1 = Orange(4, "светлый апельсин")
or2 = Orange(8, "темный апельсин")
or3 = Orange(14, "желтый апельсин")

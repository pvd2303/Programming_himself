rap = lists[0]
rap.append("Наше дело")
print(rap)
print(lists)

colors = ["синий","зеленый","желтый"]
colors
colors[2] = "красный"
colors

bill = dict({"Билл Гейтс":
                 "щедрый"})


"Билл Дорз" not in bill

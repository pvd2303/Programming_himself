locations = []


tula = (54.1960, 37.6182)
moscow = (55.7522, 37.6155)


locations.append(tula)
locations.append(moscow)


print(locations)

lists = []
rap = ["Баста",
       "Кравц",
       "Злой дух",
       "25-17"]


rock = ["Наутилус Помпилиус",
        "Кино",
        "Ария"]


djs = ["Paul Oakenfold",
       "Tiesto"]


lists.append(rap)
lists.append(rock)
lists.append(djs)


print(lists)

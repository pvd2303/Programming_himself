rndm = ("М. Джексон", 1958, True)
rndm

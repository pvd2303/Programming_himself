fruit = ["Яблоко", "Апельсин", "Персик"]
fruit.append("Банан")
fruit.append("Дыня")
fruit

colors = ["синий","зеленый","желтый"]
colors
item = colors.pop()
item
colors

facts = dict()


# добавляем значение
facts["код"] = "смешной"
# lookup a key
facts["код"]


# добавляем значение
facts["Билл"] = "Гейтс"
# lookup a key
facts["Билл"]


# добавляем значение
facts["основание"] = 1776
# lookup a key
facts["основание"]

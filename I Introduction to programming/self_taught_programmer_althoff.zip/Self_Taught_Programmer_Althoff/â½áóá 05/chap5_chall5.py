songs = {"Zodiac": "Провинциальное диско",
         "Pink Floyd": "Another Brick in the Wall",
         "Space": "Child"
}

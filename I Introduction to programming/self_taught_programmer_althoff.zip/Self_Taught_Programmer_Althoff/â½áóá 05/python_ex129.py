len(colors)

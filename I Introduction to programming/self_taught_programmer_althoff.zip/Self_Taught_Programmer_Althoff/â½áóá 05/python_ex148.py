# ПРОДОЛЖЕНИЕ
# ПРЕДЫДУЩЕГО ПРИМЕРА

rap = lists[0]
print(rappers)

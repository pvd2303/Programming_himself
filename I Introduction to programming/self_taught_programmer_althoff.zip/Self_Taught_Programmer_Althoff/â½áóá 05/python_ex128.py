colors = ["синий","зеленый","желтый"]
"черный" not in colors

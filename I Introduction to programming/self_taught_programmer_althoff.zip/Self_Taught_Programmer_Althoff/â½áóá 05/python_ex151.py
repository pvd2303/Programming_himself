eights = ["Эдгар Алан По",
          "Чарльз Диккенс"]


nines = ["Хемингуэй",
         "Фицджеральд",
         "Оруэлл"]


authors = (eights, nines)
print(authors)

fav_musicans = ["Zodiac", "Pink Floyd", "Space"]

bday = {"Хемингуэй":
        "21.07.1899",
        "Фицджеральд":
        "24.09.1896"}


my_list = [bday]
print(my_list)
my_tuple = (bday,)
print(my_tuple)

<!--Это HTML-комментарий.
Сохраните этот файл как index.html-->

<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Мой веб-сайт</title>
</head>
<body>
     Привет, мир!
     <a href="https://www.google.com">
     щелкните здесь</a>
</body>
</html>

pip freeze

$ git pull origin master

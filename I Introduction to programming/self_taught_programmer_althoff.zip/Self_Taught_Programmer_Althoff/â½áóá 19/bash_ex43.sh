$ git status

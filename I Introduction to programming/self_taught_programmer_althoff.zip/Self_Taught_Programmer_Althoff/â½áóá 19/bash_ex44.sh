$ git add hangman.py

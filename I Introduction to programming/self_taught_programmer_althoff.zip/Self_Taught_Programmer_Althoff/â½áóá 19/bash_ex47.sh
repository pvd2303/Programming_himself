$ git add hangman.py
$ git status
$ cd hangman
$ git remote -v

$ ls
>> hangman

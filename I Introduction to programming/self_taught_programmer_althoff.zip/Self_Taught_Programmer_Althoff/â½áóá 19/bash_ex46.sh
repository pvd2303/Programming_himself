$ git reset hangman.py.

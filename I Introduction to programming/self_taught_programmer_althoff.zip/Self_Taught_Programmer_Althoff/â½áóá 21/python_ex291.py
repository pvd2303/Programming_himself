stack = Stack()
stack.push(1)
print(stack.is_empty())

stack = Stack()
print(stack.is_empty())

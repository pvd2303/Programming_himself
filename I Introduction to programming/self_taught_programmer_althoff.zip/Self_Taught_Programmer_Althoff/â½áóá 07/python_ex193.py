name = "Тед"
for character in name:
    print(character)

while True:
    print("Привет, мир!")



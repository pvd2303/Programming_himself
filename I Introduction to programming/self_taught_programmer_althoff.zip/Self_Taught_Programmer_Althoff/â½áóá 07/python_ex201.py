x = 10
while x > 0:
    print('{}'.format(x))
    x -= 1
print("С Новым годом!")

for i in range(1, 3):
    print(i)
    for letter in ["а", "б", "в"]:
        print(letter)

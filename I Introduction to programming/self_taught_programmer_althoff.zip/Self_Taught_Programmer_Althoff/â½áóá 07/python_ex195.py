coms = ("Теория большого взрыва",
        "Друзья",
        "Папины дочки")
for show in coms:
    print(show)

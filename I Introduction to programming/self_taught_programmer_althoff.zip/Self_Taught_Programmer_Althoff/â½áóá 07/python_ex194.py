shows = ["Во все тяжкие",
         "Секретные материалы",
         "Фарго"]
for show in shows:
    print(show)

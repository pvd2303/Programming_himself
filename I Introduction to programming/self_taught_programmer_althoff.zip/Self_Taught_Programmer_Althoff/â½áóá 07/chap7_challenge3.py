shows = ["Ходячие мертвецы", "Красавцы", "Клан Сопрано", "Дневники вампира"]
for index, show in enumerate(shows):
    print(index)
    print(show)

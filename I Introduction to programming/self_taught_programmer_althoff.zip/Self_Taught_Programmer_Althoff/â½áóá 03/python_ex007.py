print("Хай!")

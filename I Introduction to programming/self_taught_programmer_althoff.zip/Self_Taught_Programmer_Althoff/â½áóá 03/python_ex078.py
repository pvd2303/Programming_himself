print("Майкл")






print("Джордан")

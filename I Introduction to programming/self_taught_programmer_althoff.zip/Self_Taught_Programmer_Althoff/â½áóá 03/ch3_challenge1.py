print("Выше")
print("и")
print("ниже")

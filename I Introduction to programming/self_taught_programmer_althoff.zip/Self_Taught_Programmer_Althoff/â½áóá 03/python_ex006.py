print("Python")

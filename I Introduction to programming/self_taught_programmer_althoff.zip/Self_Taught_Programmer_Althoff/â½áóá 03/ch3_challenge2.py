x = 11
if x < 10:
    print("x меньше 10.")
else:
    print("x больше или равно 10")

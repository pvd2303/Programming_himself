home = "Россия"
if home == "Россия":
    print("Привет, Россия!")
else:
    print("Привет, мир!")

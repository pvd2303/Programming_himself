age = 64
retirement = age - 65

if retirement < 10:
    print("Пора на пенсию, дружок!")
else:
    print("Дружище, тебе еще рано думать о пенсии!")

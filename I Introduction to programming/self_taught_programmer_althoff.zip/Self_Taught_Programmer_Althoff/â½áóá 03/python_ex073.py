x = 100
if x == 10:
    print("10!")
elif x == 20:
    print("20!")
else:
    print("Не знаю!")


if x == 100:
    print("x равно 100!")


if x % 2 == 0:
    print("x четное!")
else:
    print("x нечетное!")

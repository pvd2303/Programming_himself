home = "Тайланд"
if home == "Япония":
    print("Привет, Япония!")
elif home == "Тайланд":
    print("Привет, Тайланд!")
elif home == "Индия":
    print("Привет, Индия!")
elif home == "Китай":
    print("Привет, Китай!")
else:
    print("Привет, мир!")

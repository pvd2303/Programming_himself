def add_it(x, y=10):
    return x + y


result = add_it(2)
print(result)

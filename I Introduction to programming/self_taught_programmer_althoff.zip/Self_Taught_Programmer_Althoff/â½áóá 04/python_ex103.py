if x > 100:
    print("x > 100")

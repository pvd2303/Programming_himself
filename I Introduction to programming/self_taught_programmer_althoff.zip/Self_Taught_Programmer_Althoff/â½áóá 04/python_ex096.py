def even_odd():
    n = input("введите число: ")
    n = int(n)
    if n % 2 == 0:
        print("n - четное.")
    else:
        print("n - нечетное.")


even_odd()
even_odd()
even_odd()

age = input("Укажите возраст:")
int_age = int(age)
if int_age < 21:
    print("Вы - молоды!")
else:
    print("Ну вы и старик!")

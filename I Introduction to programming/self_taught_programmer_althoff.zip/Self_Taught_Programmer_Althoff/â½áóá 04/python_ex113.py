print(100)

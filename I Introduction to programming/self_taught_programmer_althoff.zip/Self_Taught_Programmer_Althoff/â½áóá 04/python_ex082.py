def f(x):
    return x + 1


z = f(4)


if z == 5:
    print("z равно 5")
else:
    print("z не равно 5")

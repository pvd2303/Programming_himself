# Продолжение
# предыдущего примера

result = f(2)
print(result)

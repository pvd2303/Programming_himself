def squared(x):
    return x ** 2

print(squared(2))

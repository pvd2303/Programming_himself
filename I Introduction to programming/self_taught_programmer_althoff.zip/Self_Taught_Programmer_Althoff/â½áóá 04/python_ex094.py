def even_odd(x):
    if x % 2 == 0:
        print("четное")
    else:
        print("нечетное")


even_odd(2)
even_odd(3)

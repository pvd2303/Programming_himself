try:
    10 / 0
    c = "Я никогда не определюсь."
except ZeroDivisionError:
    print(c)

n = input("введите число: ")
n = int(n)


if n % 2 == 0:
    print("n - четное.")
else:
    print("n - нечетное.")


n = input("введите число: ")
n = int(n)
if n % 2 == 0:
    print("n - четное.")
else:
    print("n - нечетное.")


n = input("введите число: ")
n = int(n)
if n % 2 == 0:
    print("n - четное.")
else:
    print("n - нечетное.")

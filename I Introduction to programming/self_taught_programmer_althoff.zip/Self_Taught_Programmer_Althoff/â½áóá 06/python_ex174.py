s = "    Москва        "
s = s.strip()
s

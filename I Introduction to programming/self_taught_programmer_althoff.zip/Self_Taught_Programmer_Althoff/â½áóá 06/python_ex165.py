"троглодиты...".capitalize()

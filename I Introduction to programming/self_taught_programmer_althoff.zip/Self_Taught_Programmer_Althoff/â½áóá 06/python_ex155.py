author = "Кафка"
author[0]
author[1]
author[2]
author[3]
author[4]

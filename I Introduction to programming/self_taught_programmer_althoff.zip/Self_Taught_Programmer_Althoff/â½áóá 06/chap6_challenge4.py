lst = "Где это? Кто это? Когда это?".split("?")
print(lst)

sentence = "И незачем так орать! Я и в первый раз прекрасно слышал."
slce = sentence[0:19]
print(slce)

first_index = "Хемингуэй".index("м")
print(first_index)

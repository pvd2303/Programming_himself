author = "Уильям Фолкнер"
year_born = "1897"

"""{} родился в {}."""\
   .format(author,
           year_born)
author = "Кафка"
author[-1]

equ = "Все животные одинаковы."
equ = equ.replace("о", "@")
print(equ)

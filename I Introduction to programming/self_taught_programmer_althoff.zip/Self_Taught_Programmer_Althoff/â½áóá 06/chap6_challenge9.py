concat = "три" + "три" + "три"
mult = "три" * 3

print(concat)
print(mult)

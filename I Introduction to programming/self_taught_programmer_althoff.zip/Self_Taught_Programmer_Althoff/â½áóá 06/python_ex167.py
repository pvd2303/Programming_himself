last = "Фолкнер"
"Уильям {}".format(last)

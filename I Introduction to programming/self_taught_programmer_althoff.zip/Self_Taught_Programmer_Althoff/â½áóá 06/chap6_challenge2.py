answer1 = input("Что ты написал вчера?")
answer2 = input("Куда ты ходил вчера?")

new_string = "Вчера я написал {}. Вчера я ходил в {}.".format(answer1, answer2)

print(new_string)

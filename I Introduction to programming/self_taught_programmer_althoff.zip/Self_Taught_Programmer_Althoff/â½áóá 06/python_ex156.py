author = "Кафка"
author[5]

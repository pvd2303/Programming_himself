first_three = "абв"
result = "+".join(first_three)
result

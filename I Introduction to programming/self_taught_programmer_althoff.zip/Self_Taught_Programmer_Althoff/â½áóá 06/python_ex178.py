try:
    "животные".index("з")
except:
    print("Не обнаружено.")

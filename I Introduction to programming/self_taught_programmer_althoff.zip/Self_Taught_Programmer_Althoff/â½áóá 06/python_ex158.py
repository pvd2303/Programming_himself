author = "Кафка"
author[-2]
author[-3]

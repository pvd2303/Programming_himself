sentence = "Ребенок – зеркало поступков родителей."
sentence = sentence.replace("о", "0")
print(sentence)

words = ["Рыжая",
         "лисица",
         "сделала",
         "кувырок",
         "через",
         "голову",
         "."]
one_string = " ".join(words)
one_string

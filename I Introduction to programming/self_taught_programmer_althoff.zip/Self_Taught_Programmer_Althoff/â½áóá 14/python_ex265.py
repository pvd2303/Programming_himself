x = 10
if x is None:
    print("x равно None :( ")
else:
    print("x не равно None")


x = None
if x is None:
    print("x равно None")
else:
    print("x равно None :( ")

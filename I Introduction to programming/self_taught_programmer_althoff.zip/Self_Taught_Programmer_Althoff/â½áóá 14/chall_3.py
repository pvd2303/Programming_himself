def compare(obj1, obj2):
    return obj1 is obj2

print(compare("а", "б"))
